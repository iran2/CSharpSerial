﻿// May 2017 -------------- Written in C# Form Application with Visual Studio 2013

using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.IO.Ports;


namespace Serial
{
    public partial class Form1 : Form
    {

      public SerialPort serialport1;   // This is a must to make a copy of our class
                                          // Will be used in Button Section
 
       

         public Form1()
        {

            InitializeComponent();
            getAvailablePorts();
        }

        private void label2_Click(object sender, EventArgs e)
        {

        }

        private void Form1_Load(object sender, EventArgs e)  // Open the port
        {
           
          

        }

        void getAvailablePorts()
    {
        string[] ports = SerialPort.GetPortNames();
        comboBox1.Items.AddRange(ports);
    }

        private void comboBox2_SelectedIndexChanged(object sender, EventArgs e)
        {

        }

        private void button3_Click(object sender, EventArgs e)
        {
           try
           {

               if(comboBox1.Text == "" || comboBox2.Text == "")
               {
                   textBox2.Text = "Please check your settings!"; // You have not chosen anything!

               }

               else
               {

                   
                   
                   serialport1 = new SerialPort();    // We need to define a new function for serialport1

                

                   serialport1.PortName = comboBox1.Text;
                   serialport1.BaudRate = Convert.ToInt32(comboBox2.Text);
                   serialport1.Open();
                   progressBar1.Value = 100;
                   button1.Enabled = true;
                   button2.Enabled = true;
                   textBox1.Enabled = true;
                   button3.Enabled = false;
                   button4.Enabled = true;


                   System.Threading.Thread.Sleep(500);  // wait for .5 sec
                   
                   System.Windows.Forms.MessageBox.Show("Port is open!");


               }
           }
            catch(UnauthorizedAccessException)
           {
               textBox2.Text = "Unauthorized Access";

           }
        }

        private void button4_Click(object sender, EventArgs e)
        {
        //    SerialPort1.Close();
            progressBar1.Value = 0;
            button1.Enabled = false;
            button2.Enabled = false;
            button3.Enabled = false;
            button3.Enabled = true;
            textBox1.Enabled = false;
        }

        private void progressBar1_Click(object sender, EventArgs e)
        {

        }

        private void textBox1_TextChanged(object sender, EventArgs e)
        {

        }

        private void textBox2_TextChanged(object sender, EventArgs e)
        {

        }

        private void button1_Click(object sender, EventArgs e)
        {
            serialport1.WriteLine(textBox1.Text); // Text Format 
            textBox1.Text = "";
        }

        private void button2_Click(object sender, EventArgs e)
        {
            try
            {
                textBox2.Text = serialport1.ReadLine();

            }
            catch(TimeoutException)
            {
                textBox2.Text = "Timeout Exception!";
            }
        }

        private void comboBox1_SelectedIndexChanged(object sender, EventArgs e)
        {

        }

        private void label1_Click(object sender, EventArgs e)
        {

        }

        private void label3_Click(object sender, EventArgs e)
        {

        }

    }
}
